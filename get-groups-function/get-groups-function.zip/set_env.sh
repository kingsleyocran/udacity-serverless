# This file is used for convenience of local development.
# DO NOT STORE YOUR CREDENTIALS INTO GIT
export GROUP_TABLE=Groups